#include <iostream>
#include <conio.h>
#include <fstream>
using namespace std;

int main()
{
	ofstream file_keluaran;
	file_keluaran.open("Sanksi YGY.TXT");
	cout<<"Sedang merekam.."<<endl;
	file_keluaran<<"Sanksi Perpustakaan"<<endl;
	file_keluaran<<"1. Peminjam yang terlambat mengembalikan buku (koleksi umum) dikenakan sanksi denda sebesar Rp. 1000,- (seribu rupiah) per hari/per buku"<<endl;
	file_keluaran<<"2. Menghilangkan/merusak bahan pustaka perpustakaan harus mengganti dengan bahan pustaka yang sama atau denda uang sebesar 3 (tiga) kali harga terbaru bahan pustaka tersebut."<<endl;
	file_keluaran<<"3. Penggantian bahan pustaka yang hilang/rusak harus sudah terpenuhi dalam waktu paling lambat 7 hari setelah diketahui kehilangan/kerusakan."<<endl;
	file_keluaran<<"4. Peminjam yang merusak buku perpustakaan diwajibkan untuk mengganti atau membayar ganti rugi."<<endl;
	file_keluaran.close();
}
