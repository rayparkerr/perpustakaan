#include <iostream>
#include <conio.h>
#include <string.h>
#include <fstream>
#include <stdlib.h>

using namespace std;

void garis()
{
cout<<"===============================\n";
}
class Perpustakaan
{
private :
string Judul,Penulis;
public :
void data (string judul_buku,string penulis_buku);
void info();
};
void Perpustakaan::data(string judul_buku,string penulis_buku)
{
Judul = judul_buku;
Penulis = penulis_buku;
}
void Perpustakaan::info()
{
cout<<"Judul Buku : "<<Judul<<endl;
cout<<"Penulis : "<<Penulis<<endl;
}

int main()
{
Perpustakaan Horror1;
Perpustakaan Horror2;
Perpustakaan Horror3;
Perpustakaan Comedy1;
Perpustakaan Comedy2;
Perpustakaan Comedy3;
Perpustakaan Fantasi1;
Perpustakaan Fantasi2;
Perpustakaan Fantasi3;
int pilihan;
do
{
cout <<endl;
cout << "\t\t ****";
cout << endl;
cout << "\t\t * PROGRAM TA ALGORITMA & STRUKTUR DATA - PERPUSTAKAAN YGY *";
cout << endl;
cout << "\t\t ****";
cout << endl;
cout << "\t\t PERPUSTAKAAN YGY";
cout << endl;
cout << "\t\t ****";
cout << endl;
cout << "\t\t DAFTAR MENU";
cout << endl;
cout << "\t\t ****" << endl;
cout << "\t\t *1. DAFTAR BUKU *" << endl;
cout << "\t\t *2. PEMINJAMAN BUKU *" << endl;
cout << "\t\t *3. SANKSI PERPUSTAKAAN YGY *" << endl;
cout << "\t\t ****" << endl;
cout << " Apa yang anda lakukan (1-3) : ";
cin >> pilihan;
system("CLS");
cout << endl;

switch (pilihan)
{
case 1:
mulai:
cout<<"Genre Buku Horror : "<<endl;
garis();
Horror1.data("DANUR","RISA SARASWATI");
Horror2.data("SUNYIRURI","RISA SARASWATI");
Horror3.data("jURNAL RISA","RISA SARASWATI");
Horror1.info();
Horror2.info();
Horror3.info();
cout<<endl;
cout<<"Genre Buku Comedy : "<<endl;
garis();
Comedy1.data("MANUSIA SETENGAH SALMON","RADITYA DIKA");
Comedy2.data("MARMUT MERAH JAMBU","RADITYA DIKA");
Comedy3.data("UBUR - UBUR LEMBUR","RADITYA DIKA");
Comedy1.info();
Comedy2.info();
Comedy3.info();
cout<<endl;
cout<<"Genre Buku Fanstasi : "<<endl;
garis();
Fantasi1.data("BUMI","TERE LIYE");
Fantasi2.data("BULAN","TERE LIYE");
Fantasi3.data("MATAHARI","TERE LIYE");
Fantasi1.info();
Fantasi2.info();
Fantasi3.info();
break;

case 2:
struct data
{
char npm[30];
char nama[30];
char buku[60];
char waktu[30];
} mahasiswa;
cout << "Masukan NPM        : ";
cin >> mahasiswa.npm;
cout << "Masukan Nama       : ";
fflush(stdin);
gets(mahasiswa.nama);
cout << "Judul Buku         : ";
cin >> mahasiswa.buku;
cout << "Waktu Pengembalian : ";
cin >> mahasiswa.waktu;
cout << endl;
garis();
cout << "Tampilkan Struct Data"
<< "\nNama               : " << mahasiswa.nama
<< "\nNpm                : " << mahasiswa.npm
<< "\nJudul Buku         : " << mahasiswa.buku
<< "\nWaktu Pengembalian : "<< mahasiswa.waktu;
cout << endl;
break;

case 3 :
const int MAX = 2000;
char buffer[MAX+1];
ifstream file_objek;
file_objek.open("Sanksi.txt");
cout << "Membaca Isi File Sanksi.txt\n";
while(file_objek)
{
file_objek.getline(buffer,MAX);
cout<<buffer<<endl;
}
}
}
while(pilihan != 3);
return 0;
getch();
}
